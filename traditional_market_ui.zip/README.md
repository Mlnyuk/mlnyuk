# 전통시장 배달 UI Flutter Prototype

## 구조
UI만 있는 배달의민족 스타일 인터페이스. dummy 데이터로 화면 구성.

## 사용법
1. Flutter SDK 설치
2. 루트에서: `flutter pub get`
3. 실행: `flutter run -d chrome` (web target) 또는 `flutter run`

## 주요 화면
- Home: 검색, 배너, 카테고리, 상점 리스트
- Store detail: 메뉴 확인
- Cart: 결제 버튼 (UI only)