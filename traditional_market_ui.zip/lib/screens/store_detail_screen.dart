import 'package:flutter/material.dart';
import '../models/store.dart';
import '../widgets/menu_item.dart';

class StoreDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final store = ModalRoute.of(context)!.settings.arguments as Store;
    return Scaffold(
      appBar: AppBar(title: Text(store.name)),
      body: ListView(
        children: [
          Container(height: 180, color: Colors.grey[300], child: Center(child: Text('가게 이미지'))),
          Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(store.name, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('⭐ \${store.rating} · 배달시간: \${store.deliveryTime}'),
                SizedBox(height: 16),
                Text('메뉴', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          ...store.menus.map((m) => MenuItemWidget(menu: m)).toList(),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: ElevatedButton(
          onPressed: () {},
          child: Text('장바구니 보기'),
        ),
      ),
    );
  }
}