import 'package:flutter/material.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('장바구니')),
      body: Center(child: Text('장바구니에 담긴 항목이 없습니다.')),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.all(12),
        child: ElevatedButton(onPressed: () {}, child: Text('결제하기')),
      ),
    );
  }
}