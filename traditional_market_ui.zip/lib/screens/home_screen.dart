import 'package:flutter/material.dart';
import '../widgets/banner_slider.dart';
import '../widgets/category_list.dart';
import '../widgets/store_card.dart';
import '../models/store.dart';

class HomeScreen extends StatelessWidget {
  final List<Store> dummyStores = List.generate(6, (i) => Store(
    name: '가게 \${i+1}',
    rating: 4.3,
    imageUrl: '',
    deliveryTime: '\${20 + i}분',
    menus: [
      Menu(title: '메뉴 A', description: '맛있는 A', price: 8000, imageUrl: ''),
      Menu(title: '메뉴 B', description: '매콤한 B', price: 9500, imageUrl: ''),
    ],
  ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('전통시장 배달'), actions: [
        IconButton(onPressed: () {}, icon: Icon(Icons.shopping_cart))
      ]),
      body: ListView(
        children: [
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              decoration: InputDecoration(
                hintText: '무엇을 찾으시나요?',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ),
          SizedBox(height: 12),
          BannerSlider(images: ['','','']),
          SizedBox(height: 16),
          CategoryList(categories: ['과일', '채소', '정육', '반찬', '간식']),
          SizedBox(height: 12),
          ...dummyStores.map((s) => StoreCard(store: s)).toList(),
        ],
      ),
    );
  }
}