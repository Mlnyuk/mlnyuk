import 'package:flutter/material.dart';
import 'routes.dart';
import 'package:google_fonts/google_fonts.dart';

void main() => runApp(MyMarketApp());

class MyMarketApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '전통시장 배달앱',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        textTheme: GoogleFonts.pretendardTextTheme(),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: appRoutes,
    );
  }
}