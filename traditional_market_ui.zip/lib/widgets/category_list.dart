import 'package:flutter/material.dart';

class CategoryList extends StatelessWidget {
  final List<String> categories;
  CategoryList({required this.categories});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 60,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16),
        itemBuilder: (context, i) => Chip(label: Text(categories[i])),
        separatorBuilder: (_, __) => SizedBox(width: 8),
        itemCount: categories.length,
      ),
    );
  }
}