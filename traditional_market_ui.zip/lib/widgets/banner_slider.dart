import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class BannerSlider extends StatelessWidget {
  final List<String> images;
  BannerSlider({required this.images});
  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      items: images.map((url) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
          width: double.infinity,
          color: Colors.grey[300],
          child: Center(child: Text('Banner', style: TextStyle(fontSize: 24))),
        ),
      )).toList(),
      options: CarouselOptions(
        height: 140,
        autoPlay: true,
        enlargeCenterPage: true,
        viewportFraction: 0.9,
      ),
    );
  }
}