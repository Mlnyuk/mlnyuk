import 'package:flutter/material.dart';
import '../models/store.dart';

class MenuItemWidget extends StatelessWidget {
  final Menu menu;
  const MenuItemWidget({required this.menu});
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 6, horizontal: 16),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              color: Colors.grey[200],
              child: Icon(Icons.fastfood),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(menu.title, style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text(menu.description),
                ],
              ),
            ),
            Column(
              children: [
                Text('\${menu.price.toStringAsFixed(0)}원'),
                SizedBox(height: 8),
                ElevatedButton(onPressed: () {}, child: Text('추가'))
              ],
            )
          ],
        ),
      ),
    );
  }
}