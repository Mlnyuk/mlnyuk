class Store {
  final String name;
  final double rating;
  final String imageUrl;
  final String deliveryTime;
  final List<Menu> menus;
  Store({
    required this.name,
    required this.rating,
    required this.imageUrl,
    required this.deliveryTime,
    required this.menus,
  });
}

class Menu {
  final String title;
  final String description;
  final double price;
  final String imageUrl;
  Menu({
    required this.title,
    required this.description,
    required this.price,
    required this.imageUrl,
  });
}