import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/store_detail_screen.dart';
import 'screens/cart_screen.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/': (_) => HomeScreen(),
  '/store': (_) => StoreDetailScreen(),
  '/cart': (_) => CartScreen(),
};